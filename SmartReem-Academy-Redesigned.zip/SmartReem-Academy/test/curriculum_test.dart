import 'package:flutter_test/flutter_test.dart';
import 'package:smart_reem/main.dart';

void main() {
  test('curriculum has 14 tracks and 42 lessons', () {
    expect(curriculum.length, 14);
    final lessons = curriculum.expand((track) => track.lessons).toList();
    expect(lessons.length, 42);
  });

  test('lesson IDs are unique and quiz answers are valid', () {
    final lessons = curriculum.expand((track) => track.lessons).toList();
    final ids = lessons.map((item) => item.id).toSet();
    expect(ids.length, lessons.length);
    for (final item in lessons) {
      expect(item.options.length, greaterThanOrEqualTo(2));
      expect(item.correct, inInclusiveRange(0, item.options.length - 1));
      expect(item.title, isNotEmpty);
      expect(item.explanation, isNotEmpty);
    }
  });
}
